#!/bin/bash

cat << EOF > dconf-settings.sh
notify-send "Перезаидите в сессию что бы изменения вступили в силу | please restart session By Griggorii setting my donate https://money.yandex.ru/to/410014999913799 " 
EOF
chmod -R a+rwx dconf-settings.sh && ./dconf-settings.sh && rm dconf-settings.sh
EOF
cat << EOF > dconf-settings.ini
[org/gnome/desktop/interface]
text-scaling-factor=1.0
clock-format='24h'
font-name='Ubuntu 11'
document-font-name='Sans 11'
show-battery-percentage=true
cursor-theme='breeze_cursors'
clock-show-seconds=true
gtk-im-module='gtk-im-context-simple'
icon-theme='breeze-dark'
monospace-font-name='Ubuntu Mono 11'
enable-animations=true
gtk-theme='Breeze-Dark'
clock-show-date=true
toolkit-accessibility=false
EOF
dconf load / < dconf-settings.ini && 
cat << EOF > pulseaudio.desktop
[Desktop Entry]
Type=Application
Exec=pulseaudio
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Name[ru]=pulseaudio
Name=pulseaudio
Comment[ru]=pulseaudio
Comment=pulseaudio
EOF
chmod -R a+rwx pulseaudio.desktop && mv pulseaudio.desktop ~/.config/autostart && rm -r dconf-settings.ini && rm -rf ~/.cache/* && killall budgie-panel && budgie-panel &&  killall showtime_desktop && showtime_desktop
